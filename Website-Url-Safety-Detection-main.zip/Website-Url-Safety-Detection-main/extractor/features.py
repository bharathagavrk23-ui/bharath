import re
import tldextract

def extract_features(url):
    ext = tldextract.extract(url)
    domain = ext.domain

    features = []

    # 1. Has IP address in URL
    features.append(1 if re.search(r'(\d{1,3}\.){3}\d{1,3}', url) else 0)

    # 2. URL Length
    features.append(len(url))

    # 3. SSLfinal_State (hardcoded as 1 = has valid certificate, optional improvement later)
    features.append(1)

    # 4. Prefix-Suffix in domain (has '-')
    features.append(1 if '-' in domain else 0)

    # 5. Uses shortening service
    features.append(1 if any(service in url for service in ['bit.ly', 'tinyurl', 'goo.gl']) else 0)

    # 6. Has '@' symbol
    features.append(1 if '@' in url else 0)

    # 7. Double slash redirection
    features.append(1 if url.count('//') > 1 else 0)

    # 8. HTTPS token present
    features.append(1 if url.lower().startswith('https') else 0)

    return features
